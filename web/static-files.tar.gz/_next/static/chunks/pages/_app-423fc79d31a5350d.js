(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[888],{6840:function(e,t,o){(window.__NEXT_P=window.__NEXT_P||[]).push(["/_app",function(){return o(9645)}])},9645:function(e,t,o){"use strict";o.r(t),o.d(t,{default:function(){return l}});var a=o(5893),r=o(9008),i=o.n(r),n=o(7294),s=o(6501);function l(e){let{Component:t,pageProps:o}=e;return(0,n.useEffect)(()=>{let e;"serviceWorker"in navigator&&navigator.serviceWorker.register("/flags/sw.js").then(e=>{console.log("SW registered: ",e)}).catch(e=>{console.log("SW registration failed: ",e)});let t=t=>{t.preventDefault(),e=t;let o=document.getElementById("install-button");o&&(o.style.display="block",o.addEventListener("click",()=>{e&&(e.prompt(),e.userChoice.then(t=>{"accepted"===t.outcome&&console.log("User accepted the install prompt"),e=null}))}))};window.addEventListener("beforeinstallprompt",t),window.addEventListener("appinstalled",()=>{console.log("PWA was installed");let e=document.getElementById("install-button");e&&(e.style.display="none")});let o=()=>{console.log("App is online")},a=()=>{console.log("App is offline")};return window.addEventListener("online",o),window.addEventListener("offline",a),()=>{window.removeEventListener("beforeinstallprompt",t),window.removeEventListener("appinstalled",()=>{}),window.removeEventListener("online",o),window.removeEventListener("offline",a)}},[]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)(i(),{children:[(0,a.jsx)("meta",{charSet:"utf-8"}),(0,a.jsx)("meta",{httpEquiv:"X-UA-Compatible",content:"IE=edge"}),(0,a.jsx)("meta",{name:"viewport",content:"width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"}),(0,a.jsx)("meta",{name:"description",content:"Изучайте флаги стран мира с помощью интерактивной викторины"}),(0,a.jsx)("meta",{name:"keywords",content:"флаги, страны, география, викторина, обучение"}),(0,a.jsx)("meta",{name:"application-name",content:"Флаги Мира"}),(0,a.jsx)("meta",{name:"apple-mobile-web-app-capable",content:"yes"}),(0,a.jsx)("meta",{name:"apple-mobile-web-app-status-bar-style",content:"default"}),(0,a.jsx)("meta",{name:"apple-mobile-web-app-title",content:"Флаги Мира"}),(0,a.jsx)("meta",{name:"format-detection",content:"telephone=no"}),(0,a.jsx)("meta",{name:"mobile-web-app-capable",content:"yes"}),(0,a.jsx)("meta",{name:"theme-color",content:"#4A90E2"}),(0,a.jsx)("link",{rel:"manifest",href:"/flags/manifest.json"}),(0,a.jsx)("link",{rel:"shortcut icon",href:"/flags/favicon.ico"}),(0,a.jsx)("meta",{property:"og:type",content:"website"}),(0,a.jsx)("meta",{property:"og:title",content:"Флаги Мира - Изучение географии"}),(0,a.jsx)("meta",{property:"og:description",content:"Изучайте флаги стран мира с помощью интерактивной викторины"}),(0,a.jsx)("meta",{property:"og:site_name",content:"Флаги Мира"}),(0,a.jsx)("meta",{property:"og:url",content:"https://flagsworld.com"}),(0,a.jsx)("meta",{name:"twitter:card",content:"summary"}),(0,a.jsx)("meta",{name:"twitter:url",content:"https://flagsworld.com"}),(0,a.jsx)("meta",{name:"twitter:title",content:"Флаги Мира - Изучение географии"}),(0,a.jsx)("meta",{name:"twitter:description",content:"Изучайте флаги стран мира с помощью интерактивной викторины"}),(0,a.jsx)("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),(0,a.jsx)("link",{rel:"preconnect",href:"https://fonts.gstatic.com",crossOrigin:"anonymous"}),(0,a.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap",rel:"stylesheet"}),(0,a.jsx)("title",{children:"Флаги Мира - Изучение географии"})]}),(0,a.jsx)("div",{className:"min-h-screen bg-gray-50 dark:bg-gray-900",children:(0,a.jsx)(t,{...o})}),(0,a.jsx)(s.x7,{position:"top-center",toastOptions:{duration:4e3,style:{background:"#363636",color:"#fff"},success:{duration:3e3,iconTheme:{primary:"#22C55E",secondary:"#fff"}},error:{duration:5e3,iconTheme:{primary:"#EF4444",secondary:"#fff"}}}})]})}o(3434)},3434:function(){},9008:function(e,t,o){e.exports=o(3867)},6501:function(e,t,o){"use strict";let a,r;o.d(t,{x7:function(){return ep},ZP:function(){return eu}});var i,n=o(7294);let s={data:""},l=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||s,c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,p=/\n+/g,u=(e,t)=>{let o="",a="",r="";for(let i in e){let n=e[i];"@"==i[0]?"i"==i[1]?o=i+" "+n+";":a+="f"==i[1]?u(n,i):i+"{"+u(n,"k"==i[1]?"":t)+"}":"object"==typeof n?a+=u(n,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=n&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=u.p?u.p(i,n):i+":"+n+";")}return o+(t&&r?t+"{"+r+"}":r)+a},m={},f=e=>{if("object"==typeof e){let t="";for(let o in e)t+=o+f(e[o]);return t}return e},g=(e,t,o,a,r)=>{var i;let n=f(e),s=m[n]||(m[n]=(e=>{let t=0,o=11;for(;t<e.length;)o=101*o+e.charCodeAt(t++)>>>0;return"go"+o})(n));if(!m[s]){let t=n!==e?e:(e=>{let t,o,a=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?a.shift():t[3]?(o=t[3].replace(p," ").trim(),a.unshift(a[0][o]=a[0][o]||{})):a[0][t[1]]=t[2].replace(p," ").trim();return a[0]})(e);m[s]=u(r?{["@keyframes "+s]:t}:t,o?"":"."+s)}let l=o&&m.g?m.g:null;return o&&(m.g=m[s]),i=m[s],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=a?i+t.data:t.data+i),s},y=(e,t,o)=>e.reduce((e,a,r)=>{let i=t[r];if(i&&i.call){let e=i(o),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":u(e,""):!1===e?"":e}return e+a+(null==i?"":i)},"");function h(e){let t=this||{},o=e.call?e(t.p):e;return g(o.unshift?o.raw?y(o,[].slice.call(arguments,1),t.p):o.reduce((e,o)=>Object.assign(e,o&&o.call?o(t.p):o),{}):o,l(t.target),t.g,t.o,t.k)}h.bind({g:1});let b,x,v,w=h.bind({k:1});function j(e,t){let o=this||{};return function(){let a=arguments;function r(i,n){let s=Object.assign({},i),l=s.className||r.className;o.p=Object.assign({theme:x&&x()},s),o.o=/ *go\d+/.test(l),s.className=h.apply(o,a)+(l?" "+l:""),t&&(s.ref=n);let c=e;return e[0]&&(c=s.as||e,delete s.as),v&&c[0]&&v(s),b(c,s)}return t?t(r):r}}var E=e=>"function"==typeof e,k=(e,t)=>E(e)?e(t):e,$=(a=0,()=>(++a).toString()),_=()=>{if(void 0===r&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");r=!e||e.matches}return r},N=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:o}=t;return N(e,{type:e.toasts.find(e=>e.id===o.id)?1:0,toast:o});case 3:let{toastId:a}=t;return{...e,toasts:e.toasts.map(e=>e.id===a||void 0===a?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let r=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+r}))}}},O=[],C={toasts:[],pausedAt:void 0},D=e=>{C=N(C,e),O.forEach(e=>{e(C)})},A={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},L=(e={})=>{let[t,o]=(0,n.useState)(C),a=(0,n.useRef)(C);(0,n.useEffect)(()=>(a.current!==C&&o(C),O.push(o),()=>{let e=O.indexOf(o);e>-1&&O.splice(e,1)}),[]);let r=t.toasts.map(t=>{var o,a,r;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(o=e[t.type])?void 0:o.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||A[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...t,toasts:r}},I=(e,t="blank",o)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...o,id:(null==o?void 0:o.id)||$()}),P=e=>(t,o)=>{let a=I(t,e,o);return D({type:2,toast:a}),a.id},z=(e,t)=>P("blank")(e,t);z.error=P("error"),z.success=P("success"),z.loading=P("loading"),z.custom=P("custom"),z.dismiss=e=>{D({type:3,toastId:e})},z.remove=e=>D({type:4,toastId:e}),z.promise=(e,t,o)=>{let a=z.loading(t.loading,{...o,...null==o?void 0:o.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?k(t.success,e):void 0;return r?z.success(r,{id:a,...o,...null==o?void 0:o.success}):z.dismiss(a),e}).catch(e=>{let r=t.error?k(t.error,e):void 0;r?z.error(r,{id:a,...o,...null==o?void 0:o.error}):z.dismiss(a)}),e};var T=(e,t)=>{D({type:1,toast:{id:e,height:t}})},S=()=>{D({type:5,time:Date.now()})},F=new Map,M=1e3,H=(e,t=M)=>{if(F.has(e))return;let o=setTimeout(()=>{F.delete(e),D({type:4,toastId:e})},t);F.set(e,o)},W=e=>{let{toasts:t,pausedAt:o}=L(e);(0,n.useEffect)(()=>{if(o)return;let e=Date.now(),a=t.map(t=>{if(t.duration===1/0)return;let o=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(o<0){t.visible&&z.dismiss(t.id);return}return setTimeout(()=>z.dismiss(t.id),o)});return()=>{a.forEach(e=>e&&clearTimeout(e))}},[t,o]);let a=(0,n.useCallback)(()=>{o&&D({type:6,time:Date.now()})},[o]),r=(0,n.useCallback)((e,o)=>{let{reverseOrder:a=!1,gutter:r=8,defaultPosition:i}=o||{},n=t.filter(t=>(t.position||i)===(e.position||i)&&t.height),s=n.findIndex(t=>t.id===e.id),l=n.filter((e,t)=>t<s&&e.visible).length;return n.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+r,0)},[t]);return(0,n.useEffect)(()=>{t.forEach(e=>{if(e.dismissed)H(e.id,e.removeDelay);else{let t=F.get(e.id);t&&(clearTimeout(t),F.delete(e.id))}})},[t]),{toasts:t,handlers:{updateHeight:T,startPause:S,endPause:a,calculateOffset:r}}},U=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,B=w`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,X=w`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,q=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${U} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${B} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${X} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,R=w`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,Z=j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${R} 1s linear infinite;
`,Y=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,G=w`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,J=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Y} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${G} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,K=j("div")`
  position: absolute;
`,Q=j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,V=w`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ee=j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${V} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,et=({toast:e})=>{let{icon:t,type:o,iconTheme:a}=e;return void 0!==t?"string"==typeof t?n.createElement(ee,null,t):t:"blank"===o?null:n.createElement(Q,null,n.createElement(Z,{...a}),"loading"!==o&&n.createElement(K,null,"error"===o?n.createElement(q,{...a}):n.createElement(J,{...a})))},eo=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ea=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,er=j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,ei=j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,en=(e,t)=>{let o=e.includes("top")?1:-1,[a,r]=_()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[eo(o),ea(o)];return{animation:t?`${w(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${w(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},es=n.memo(({toast:e,position:t,style:o,children:a})=>{let r=e.height?en(e.position||t||"top-center",e.visible):{opacity:0},i=n.createElement(et,{toast:e}),s=n.createElement(ei,{...e.ariaProps},k(e.message,e));return n.createElement(er,{className:e.className,style:{...r,...o,...e.style}},"function"==typeof a?a({icon:i,message:s}):n.createElement(n.Fragment,null,i,s))});i=n.createElement,u.p=void 0,b=i,x=void 0,v=void 0;var el=({id:e,className:t,style:o,onHeightUpdate:a,children:r})=>{let i=n.useCallback(t=>{if(t){let o=()=>{a(e,t.getBoundingClientRect().height)};o(),new MutationObserver(o).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return n.createElement("div",{ref:i,className:t,style:o},r)},ec=(e,t)=>{let o=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:_()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(o?1:-1)}px)`,...o?{top:0}:{bottom:0},...a}},ed=h`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ep=({reverseOrder:e,position:t="top-center",toastOptions:o,gutter:a,children:r,containerStyle:i,containerClassName:s})=>{let{toasts:l,handlers:c}=W(o);return n.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:s,onMouseEnter:c.startPause,onMouseLeave:c.endPause},l.map(o=>{let i=o.position||t,s=ec(i,c.calculateOffset(o,{reverseOrder:e,gutter:a,defaultPosition:t}));return n.createElement(el,{id:o.id,key:o.id,onHeightUpdate:c.updateHeight,className:o.visible?ed:"",style:s},"custom"===o.type?k(o.message,o):r?r(o):n.createElement(es,{toast:o,position:i}))}))},eu=z}},function(e){var t=function(t){return e(e.s=t)};e.O(0,[774,179],function(){return t(6840),t(3079)}),_N_E=e.O()}]);