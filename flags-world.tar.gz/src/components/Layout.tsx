import { ReactNode } from 'react';
import { useRouter } from 'next/router';
import { useGameStore } from '../lib/gameStore';
import { useTranslation } from '../lib/translations';

interface LayoutProps {
  children: ReactNode;
  title?: string;
  showBackButton?: boolean;
  hideLanguageSelector?: boolean;
}

export default function Layout({ children, title, showBackButton = false, hideLanguageSelector = false }: LayoutProps) {
  const router = useRouter();
  const { language, setLanguage } = useGameStore();
  const { t } = useTranslation(language);

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'uk', name: 'Українська', flag: '🇺🇦' },
    { code: 'ca', name: 'Català', flag: '🏴󠁥󠁳󠁣󠁴󠁿' },
    { code: 'ru', name: 'Русский', flag: '🇷🇺' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
  ];

  const navigationItems = [
    { href: '/', label: t.home, icon: '🏠' },
    { href: '/statistics', label: t.statistics, icon: '📊' },
    { href: '/leaderboard', label: t.leaderboard, icon: '🏆' },
    { href: '/about', label: t.about, icon: '👨‍👦' },
    { href: '/settings', label: t.settings, icon: '⚙️' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between">
            {/* Left side - Back button, logo, title and navigation */}
            <div className="flex items-center space-x-6">
              {showBackButton && (
                <button
                  onClick={() => router.back()}
                  className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                >
                  ← {t.back}
                </button>
              )}
              <div className="flex items-center space-x-3">
                {/* Logo */}
                <div className="w-24 h-24 flex items-center justify-center">
                  <img 
                    src="/logo-worldarena-games.png" 
                    alt="WorldArena.Games Logo" 
                    className="w-24 h-24 rounded-lg"
                    onError={(e) => {
                      // Final fallback to text logo
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling.style.display = 'flex';
                    }}
                  />
                  <div className="w-24 h-24 bg-primary-500 rounded-lg items-center justify-center hidden">
                    <span className="text-white font-bold text-3xl">W</span>
                  </div>
                </div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  {title || t.appTitle || '🌍 Флаги Мира'}
                </h1>
              </div>
              
              {/* Navigation in header */}
              <div className="flex items-center space-x-2">
                {navigationItems.map((item) => {
                  const isActive = router.pathname === item.href || 
                    (item.href !== '/' && router.pathname.startsWith(item.href));
                  
                  return (
                    <button
                      key={item.href}
                      onClick={() => router.push(item.href)}
                      className={`flex items-center space-x-3 px-5 py-3 text-base font-medium transition-colors whitespace-nowrap rounded-xl ${
                        isActive
                          ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/20 shadow-sm'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-gray-700 hover:shadow-sm'
                      }`}
                    >
                      <span className="text-xl">{item.icon}</span>
                      <span className="font-semibold">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right side - Language selector */}
            {!hideLanguageSelector && (
              <div className="flex items-center space-x-4">
                {/* Language Dropdown */}
                <div className="relative group">
                  <button className="flex items-center space-x-2 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-primary-300 transition-colors">
                    <span className="text-lg">
                      {languages.find(lang => lang.code === language)?.flag || '🇷🇺'}
                    </span>
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {languages.find(lang => lang.code === language)?.name || 'Русский'}
                    </span>
                    <span className="text-gray-400">▼</span>
                  </button>
                  
                  {/* Dropdown Menu */}
                  <div className="absolute right-0 top-full mt-1 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => setLanguage(lang.code)}
                        className={`w-full flex items-center space-x-3 px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors first:rounded-t-lg last:rounded-b-lg ${
                          language === lang.code ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        <span className="text-lg">{lang.flag}</span>
                        <span className="font-medium">{lang.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* PWA Install Button */}
      <button
        id="install-button"
        className="fixed bottom-4 right-4 bg-primary-500 text-white px-4 py-2 rounded-lg shadow-lg hover:bg-primary-600 transition-colors duration-200 hidden"
      >
        {t.installApp}
      </button>
    </div>
  );
} 