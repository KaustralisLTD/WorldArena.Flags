const withPWA = require('next-pwa')({
  dest: 'public',
  register: true,
  skipWaiting: true,
  disable: process.env.NODE_ENV === 'development',
  // Exclude problematic files from precaching
  buildExcludes: [
    /Logo-WorldArena\.Games-2-58x58-old\.png$/,
    /\.map$/,
    /manifest$/,
    /build-manifest\.json$/,
    /react-loadable-manifest\.json$/
  ],
  runtimeCaching: [
    {
      urlPattern: /^https:\/\/restcountries\.com\/.*$/i,
      handler: 'CacheFirst',
      options: {
        cacheName: 'countries-api',
        expiration: {
          maxEntries: 1,
          maxAgeSeconds: 24 * 60 * 60, // 24 hours
        },
      },
    },
    {
      urlPattern: /\.(?:png|jpg|jpeg|svg|gif|webp)$/i,
      handler: 'CacheFirst',
      options: {
        cacheName: 'images',
        expiration: {
          maxEntries: 50,
          maxAgeSeconds: 30 * 24 * 60 * 60, // 30 days
        },
      },
    },
  ],
});

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  // Remove basePath for Vercel deployment
  // basePath: process.env.NODE_ENV === 'production' ? '/flags' : '',
  // assetPrefix: process.env.NODE_ENV === 'production' ? '/flags' : '',
  
  // Environment-specific configuration
  env: {
    CUSTOM_KEY: 'flags-world-app',
  },
  
  // Optimize for production
  swcMinify: true,
  
  // Headers for security
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ];
  },
};

module.exports = withPWA(nextConfig); 